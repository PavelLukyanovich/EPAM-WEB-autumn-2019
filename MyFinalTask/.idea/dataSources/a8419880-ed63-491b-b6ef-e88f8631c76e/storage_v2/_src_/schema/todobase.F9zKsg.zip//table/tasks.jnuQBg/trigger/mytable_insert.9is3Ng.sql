create definer = root@localhost trigger MyTable_INSERT
    before INSERT
    on tasks
    for each row
BEGIN
    SET new.CREATEDATE = now();
END;

